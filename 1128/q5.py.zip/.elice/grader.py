import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()


def answer_func(x, y):
    return x + y


def grade():
    import main as submission
    total_score = 0

    # TEST CASES
    testcases = [(3, 5), (10, 20), (473, 1947)]
    scores = [30, 30, 40]

    for testcase_index in range(len(testcases)):
        testcase = testcases[testcase_index]
        current_prob_score = scores[testcase_index]

        student_answer = submission.simple_task(testcase[0], testcase[1])
        correct_answer = answer_func(testcase[0], testcase[1])

        # COMPARE TWO SOLUTIONS
        if student_answer == correct_answer:
            # IF CORRECT, ADD SCORE
            total_score += current_prob_score
            elice_utils.secure_send_grader('Testcase %d: accept (%d points)\n' %
                                           (testcase_index + 1, current_prob_score))
        else:
            elice_utils.secure_send_grader('Testcase %d: wrong\n' % (testcase_index + 1))

    elice_utils.secure_send_image('elice.png')
    elice_utils.secure_send_file('main.py')
    elice_utils.secure_send_grader('\nTotal score: %d points\n' % (total_score))

    # SEND SCORE TO ELICE
    elice_utils.secure_send_score(total_score)


try:
    elice_utils.secure_init()
    grade()
except Exception as ex:
    elice_utils.secure_send_grader(
        'An exception occurred testing your implementation. '
        'Please run and check that it works before submitting.\n')

    # Do not send `str(ex)` because students can exploit the message
    # to see the grader content such like `raise Exception(answer_text)`.
    if isinstance(ex, ZeroDivisionError):
        elice_utils.secure_send_grader('Error info: a value is divided by zero')
    elif isinstance(ex, NameError):
        elice_utils.secure_send_grader('Error info: a variable is used without definition')
    else:
        elice_utils.secure_send_grader('Error info: unavailable')

    elice_utils.secure_send_score(0)
    sys.exit(1)
