import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()

from PIL import Image
import numpy as np
import os

def grade():
    import main as submission
    import solution

    # TEST CASES
    data_path = "dataset/val/dogs"
    names = os.listdir(data_path)
    
    total_score = 0
    scores = [25, 35, 40]
    
    # load_image
    sol_img = solution.load_image(data_path, names[0])
    sub_img = submission.load_image(data_path, names[0])
    
    sol_img = np.array(sol_img)
    sub_img = np.array(sub_img)
    if np.array_equal(sol_img, sub_img):
        total_score += scores[0]
        elice_utils.secure_send_grader("[지시사항 1] load_image 함수를 올바르게 구현하였습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 1] load_image 함수를 다시 구현하세요.\n")
        
    # [지시사항 2번]
    sub_pil_size, sub_np_img, sub_np_shape, sub_np_pix, sub_resized_img = submission.main()
    sol_pil_size, sol_np_img, sol_np_shape, sol_np_pix, sol_resized_img = solution.main()
    
    if sub_pil_size == sol_pil_size and np.array_equal(sub_np_img, sol_np_img) and (sub_np_shape == sol_np_shape):
        total_score += scores[1]
        elice_utils.secure_send_grader("[지시사항 2] 이미지의 크기와 numpy 변환을 올바르게 구현하였습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 2] 이미지의 크기와 numpy 변환을 다시 sol_resized_img.\n")
        
    # [지시사항 3번]
    if np.array_equal(sub_np_pix, sol_np_pix) and np.array_equal(np.array(sub_resized_img), np.array(sol_resized_img)):
        total_score += scores[2]
        elice_utils.secure_send_grader("[지시사항 3] 이미지의 픽셀값 추출과 resize를 올바르게 구현하였습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 3] 이미지의 픽셀값 추출과 resize를 다시 구현하세요.\n")

    elice_utils.secure_send_grader('\n총점: %d 점\n' % (total_score))

    # SEND SCORE TO ELICE
    elice_utils.secure_send_score(total_score)


try:
    elice_utils.secure_init()
    grade()
except Exception as ex:
    elice_utils.secure_send_grader(
        'An exception occurred testing your implementation. '
        'Please run and check that it works before submitting.: {}\n'.format(ex))

    # Do not send `str(ex)` because students can exploit the message
    # to see the grader content such like `raise Exception(answer_text)`.
    if isinstance(ex, ZeroDivisionError):
        elice_utils.secure_send_grader('Error info: a value is divided by zero')
    elif isinstance(ex, NameError):
        elice_utils.secure_send_grader('Error info: a variable is used without definition')
    else:
        elice_utils.secure_send_grader('Error info: unavailable')

    elice_utils.secure_send_score(0)
    sys.exit(1)
