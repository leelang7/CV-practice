import enum
import functools
import json
import os.path
import re
import subprocess
import time
from io import StringIO
from typing import (Any, Callable, Dict, List, NamedTuple, Optional, Union,
                    cast, overload)
import sys

sys.path.append(os.getcwd())

from elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()


class RunnerResult(NamedTuple):
    returncode: Optional[int]
    stdout: str
    stderr: str
    run_duration: float
    is_process_timeout: bool


def run_student_code(
    *,
    cmd: str,
    input_: Optional[str] = None,
    timeout: Optional[float] = None,
) -> RunnerResult:
    run_start_time = time.perf_counter()
    stdout = stderr = ''
    try:
        p = subprocess.Popen(
            args=cmd,
            stdin=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdout=subprocess.PIPE,
            encoding='utf-8',
            errors='replace',
        )
        stdout, stderr = p.communicate(input=input_, timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        # NOTE: `p.communicate()` after `p.kill()` can hang (https://bugs.python.org/issue38207)
        p.wait()
        returncode = p.returncode
        is_process_timeout = True
    else:
        returncode = p.returncode
        is_process_timeout = False

    run_duration = time.perf_counter() - run_start_time

    return RunnerResult(
        returncode=returncode,
        run_duration=run_duration,
        stdout=stdout,
        stderr=stderr,
        is_process_timeout=is_process_timeout,
    )
    
    






def equal_check(s,a,q_msg,score):
    elice_utils.secure_send_grader(q_msg+" (%d점)"%score)
    try:
        if s == a :
            elice_utils.secure_send_grader('---정답입니다. (+%d)\n'%score)
            return score
        else:
            elice_utils.secure_send_grader('---오답입니다.\n')
            return 0            
    except:
        elice_utils.secure_send_grader('---오답입니다.\n')
        return 0


import main as sub
import sol as sol

def grade():
    r = run_student_code(cmd=["bash" ,".elice/runner.sh"])
    student_output = r.stdout.split('\n')

    total_score = 0  
    
    sol_img = sol.load_image("dataset/val/dogs","dog.0.jpg")


    total_score += equal_check(sub.load_image("dataset/val/dogs","dog.0.jpg"),
    sol_img,
    "1: load_image 완성하기",10)
    
    total_score += equal_check(student_output[0],
    "PIL size: (499, 375)",
    "2-1: PIL 이미지의 크기를 확인하기",
    10)
    
    total_score += equal_check(sol.image2numpy(sol_img).shape,sub.image2numpy(sol_img).shape,
    "2-2: numpy 배열로 변환하기",
    20)
    
    total_score += equal_check(student_output[1],
    'np shape: (375, 499, 3)',
    "2-3: numpy 이미지의 크기를 확인하기",
    20)
    
    total_score += equal_check(student_output[3],
    '[135 133 144]',
    "3-1: 특정 위치의 픽셀값 가져오기",
    20)
    
    total_score += equal_check(student_output[4],
    'resized: (224, 224)',
    "3-2: 이미지 크기 바꾸기",
    20)
    elice_utils.secure_send_grader("채점을 마쳤습니다....\n 총점: %d / %d"%(total_score,100))
    elice_utils.secure_send_score(total_score)
    

try:
    elice_utils.secure_init()
    elice_utils.secure_send_grader("채점을 시작합니다...\n")
    elice_utils.secure_send_grader("="*32 + "\n")
    grade()
except Exception:
    # print_exc()
    elice_utils.secure_send_grader('채점 중 오류가 발생하였습니다.\n실행 버튼을 눌러 코드 실행에 오류가 없는지 확인해주세요.')
    elice_utils.secure_send_score(0)
    sys.exit(1)
