python3 -u main.py
bash