import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()


def elice_print(text):
    elice_utils.secure_send_grader(text)

def check_ans(value, answer, score):
    try:
        if value==answer:
            elice_print("...정답 (+%d)\n"%score)
            return score
        else:
            elice_print("...오답 (+0)\n")
            return 0
    except:
        elice_print("...오답 (+0)\n")
        return 0


def grade():
    import main as sb
    import ans
    
    scores= [10,10,20,20,20,20]
    
    score = 0
    elice_print("1-2")
    score += check_ans(sb.first_gen.rescale,None,scores[0]) # 1-1 rescale 매개변수도 전달하지 않은 것 확인
    elice_print("1-2")
    score += check_ans(sb.first_set.directory,'dataset/val',scores[1]) # 1-2 검증 데이터의 경로인지 확인
    
    elice_print("2-1")
    score += check_ans(sb.second_gen.rescale,1/255,scores[2]) # 2-1 rescale 매개변수가 1/255인지 확인
    elice_print("2-2")    
    score += check_ans(sb.second_set.directory,'dataset/val',scores[3]) # 2-2 검증 데이터의 경로인지 확인
    
    # 3-1
    elice_print("3-1")
    score += check_ans((sb.train_gen.__class__ == ans.train_gen.__class__) and # 일단 제대로 ImageDataGenerator 사용했는지 확인
    sb.train_gen.rescale == 1/255 and # rescale 매개변수가 1/255인지 확인
    sb.training_set.directory == 'dataset/train', True, scores[4]   # 학습 데이터 폴더인지 확인
    )
    # 3-2
    elice_print("3-2")
    score += check_ans((sb.val_gen.__class__ == ans.val_gen.__class__) and # 일단 제대로 ImageDataGenerator 사용했는지 확인
    sb.val_gen.rescale == 1/255 and # rescale 매개변수가 1/255인지 확인
    sb.validation_set.directory == 'dataset/val', True, scores[5]   # 검증 데이터 폴더인지 확인
    )
    
    elice_print("총 점수는 %d / %d 입니다."%(score,sum(scores)))
    # elice_utils.secure_send_image('elice.png')
    elice_utils.secure_send_file('main.py')
    elice_utils.secure_send_score(score)

elice_utils.secure_init()
grade()
# try:
#     elice_utils.secure_init()
#     grade()
# except Exception as ex:
#     elice_utils.secure_send_grader(
#         'An exception occurred testing your implementation. '
#         'Please run and check that it works before submitting.\n')

#     # Do not send `str(ex)` because students can exploit the message
#     # to see the grader content such like `raise Exception(answer_text)`.
#     if isinstance(ex, ZeroDivisionError):
#         elice_utils.secure_send_grader('Error info: a value is divided by zero')
#     elif isinstance(ex, NameError):
#         elice_utils.secure_send_grader('Error info: a variable is used without definition')
#     else:
#         elice_utils.secure_send_grader('Error info: unavailable')

#     elice_utils.secure_send_score(0)
#     sys.exit(1)
