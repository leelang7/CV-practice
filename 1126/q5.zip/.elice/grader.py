import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()

from PIL import Image
import numpy as np
import os

def grade():
    import main as submission
    import solution

    # TEST CASES
    total_score = 0
    scores = [30, 30, 40]
    
    sub_first_gen, sub_second_gen, sub_train_gen, sub_train_set, sub_valid_gen, sub_valid_set = submission.main()
    sol_first_gen, sol_second_gen, sol_train_gen, sol_train_set, sol_valid_gen, sol_valid_set = solution.main()
    
    # [지시사항 1번]
    if sub_first_gen.rescale == None:
        total_score += scores[0]
        elice_utils.secure_send_grader("[지시사항 1] 정규화 과정이 없는 ImageDataGenerator를 올바르게 만들었습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 1] 정규화 과정이 없는 ImageDataGenerator를 다시 만드세요.\n")
        
    # [지시사항 2번]
    if sub_second_gen.rescale == 1 /255:
        total_score += scores[1]
        elice_utils.secure_send_grader("[지시사항 2] 정규화 과정을 추가한 ImageDataGenerator를 올바르게 만들었습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 2] 정규화 과정을 추가한 ImageDataGenerator를 다시 만드세요.\n")
        
    # [지시사항 3번]
    if (sub_train_gen.__class__ == sol_train_gen.__class__) and (sub_train_set.directory == sol_train_set.directory) and \
       (sub_valid_gen.__class__ == sol_valid_gen.__class__) and (sub_valid_set.directory == sol_valid_set.directory):
        total_score += scores[2]
        elice_utils.secure_send_grader("[지시사항 3] 학습과 검증을 위한 ImageDataGenerator를 올바르게 만들었습니다!\n")
    else:
        elice_utils.secure_send_grader("[지시사항 3] 학습과 검증을 위한 ImageDataGenerator를 다시 만드세요.\n")

    elice_utils.secure_send_grader('\n총점: %d 점\n' % (total_score))

    # SEND SCORE TO ELICE
    elice_utils.secure_send_score(total_score)


try:
    elice_utils.secure_init()
    grade()
except Exception as ex:
    elice_utils.secure_send_grader(
        'An exception occurred testing your implementation. '
        'Please run and check that it works before submitting.: {}\n'.format(ex))

    # Do not send `str(ex)` because students can exploit the message
    # to see the grader content such like `raise Exception(answer_text)`.
    if isinstance(ex, ZeroDivisionError):
        elice_utils.secure_send_grader('Error info: a value is divided by zero')
    elif isinstance(ex, NameError):
        elice_utils.secure_send_grader('Error info: a variable is used without definition')
    else:
        elice_utils.secure_send_grader('Error info: unavailable')

    elice_utils.secure_send_score(0)
    sys.exit(1)
